package com.student.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.student.dto.Admin;

@WebServlet("/validateadmin")
public class AdminLogin extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("rahul");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Query query=em.createQuery("select a from Admin a where a.email=?1 and a.password=?2");
		query.setParameter(1, email);
		query.setParameter(2, password);
		List<Admin> admin= query.getResultList();
		
		if(admin.size()>0) {
			PrintWriter pw=resp.getWriter();
			pw.println("<span style=\"color: green;\">Login success</span>");
			
			RequestDispatcher rd=req.getRequestDispatcher("studentoperation.html");
			rd.include(req, resp);
			resp.setContentType("text/html");
		}
		else {
			PrintWriter pw=resp.getWriter();
			pw.println("<span style=\"color: red;\">Invalid email or password</span>");
			
			RequestDispatcher rd=req.getRequestDispatcher("adminlogin.html");
			rd.include(req, resp);
			resp.setContentType("text/html");
		}
	}

}
