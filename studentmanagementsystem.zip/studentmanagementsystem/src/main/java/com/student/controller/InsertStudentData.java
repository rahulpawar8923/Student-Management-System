package com.student.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.student.dto.Admin;
import com.student.dto.Student;

@WebServlet("/insertstudent")
public class InsertStudentData extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id=req.getParameter("id");
		String name=req.getParameter("name");
		String mobilenumber=req.getParameter("mobilenumber");
		String email=req.getParameter("email");
		String address=req.getParameter("address");
		String marks=req.getParameter("marks");
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("rahul");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Student student = new Student();
		student.setId(Integer.parseInt(id));
		student.setName(name);
		student.setMobilenumber(Long.parseLong(mobilenumber));
		student.setEmail(email);
		student.setAddress(address);
		student.setMarks(Double.parseDouble(marks));
		
		List<Student> list = new ArrayList<Student>();
		list.add(student);
		
		et.begin();
		em.persist(student);
		et.commit();
		
		PrintWriter pw=resp.getWriter();
		pw.println("<span style=\"color: green;\">Student data saved</span>");
		
		RequestDispatcher rd=req.getRequestDispatcher("studentoperation.html");
		rd.include(req, resp);
		resp.setContentType("text/html");
	}

}
